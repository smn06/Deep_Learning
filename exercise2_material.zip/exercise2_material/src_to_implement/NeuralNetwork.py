import copy
import numpy as np

#Initializes the neural network with arguments optimizer, weights_initializer, bias_initializer
class NeuralNetwork:
    def __init__(self, optimizer, weights_initializer, bias_initializer):

        self.optimizer = optimizer
        self.loss_history = []         # Stores training loss after each iteration
        self.layers = []               # All layers in the network
        self.data_layer = None         # Responsible for providing input-label pairs
        self.loss_layer = None         # Computes forward and backward loss

        # Deepcopy to prevent sharing of initializers across layers
        self.weights_initializer = copy.deepcopy(weights_initializer)
        self.bias_initializer = copy.deepcopy(bias_initializer)
    
    #Perform one forward pass through all layers and compute the loss.
    def forward(self):

        input_batch, self.current_labels = copy.deepcopy(self.data_layer.next())
        activation = input_batch

        # Propagate through all layers
        for layer in self.layers:
            activation = layer.forward(activation)

        # Compute final loss using predictions and ground truth
        return self.loss_layer.forward(activation, copy.deepcopy(self.current_labels))

    #Perform one backward pass through the network to compute gradients.
    def backward(self):
        error = self.loss_layer.backward(copy.deepcopy(self.current_labels))

        # Backpropagate through all layers in reverse order
        for layer in reversed(self.layers):
            error = layer.backward(error)

    #Appends a layer to the network. Initializes weights and sets optimizer if trainable.
    def append_layer(self, layer):

        if layer.trainable:
            layer.initialize(self.weights_initializer, self.bias_initializer)
            layer.optimizer = copy.deepcopy(self.optimizer)

        self.layers.append(layer)
    
    #Train the network for a given number of iterations.
    def train(self, iterations):

        for _ in range(iterations):
            loss = self.forward()
            self.loss_history.append(loss)
            self.backward()
    
    #Performs a forward pass through the network using test input.
    def test(self, input_tensor):
        
        for layer in self.layers:
            input_tensor = layer.forward(input_tensor)
        return input_tensor
