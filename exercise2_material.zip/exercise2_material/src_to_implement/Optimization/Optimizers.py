import numpy as np

class Sgd:
    def __init__(self, learning_rate: float):
        # Initialize SGD optimizer with a fixed learning rate
        self.lr = learning_rate

    def calculate_update(self, current_weights: np.ndarray, current_grads: np.ndarray):
        # Perform basic gradient descent update: w = w - lr * grad
        return current_weights - self.lr * current_grads


class SgdWithMomentum:
    def __init__(self, learning_rate, momentum_rate):

        self.lr = learning_rate
        self.momentum = momentum_rate
        self.velocity_history = {}  # Dictionary to store velocity vectors per unique weight shape

    def calculate_update(self, current_weights, current_grads):

        # Use the shape of the tensor as a key to track individual momentum vectors per layer
        key = str(np.shape(current_weights))

        # Initialize velocity vector for this shape if it does not exist yet
        if key not in self.velocity_history:
            self.velocity_history[key] = np.zeros_like(current_grads)

        # Update the velocity: v = μ * v - lr * grad
        self.velocity_history[key] = (
            self.momentum * self.velocity_history[key] - self.lr * current_grads
        )

        # Apply the update: w = w + v
        return current_weights + self.velocity_history[key]


class Adam:
    def __init__(self, learning_rate, mu, rho):

        self.lr = learning_rate
        self.beta1 = mu   # First moment decay rate (β1)
        self.beta2 = rho  # Second moment decay rate (β2)
        self.step_counter = {}        # Tracks timestep per unique tensor shape
        self.moment_estimates = {}    # Dictionary storing first and second moment vectors
        self.epsilon = 1e-8           # Small constant for numerical stability

    def calculate_update(self, current_weights, current_grads):

        # Identify each tensor by its shape
        key = str(np.shape(current_weights))

        # Initialize first (m) and second (v) moment estimates and step counter
        if key not in self.moment_estimates:
            self.moment_estimates[key] = [
                np.zeros_like(current_grads),  # m (first moment)
                np.zeros_like(current_grads)   # v (second moment)
            ]
            self.step_counter[key] = 0

        # Retrieve moment estimates
        m, v = self.moment_estimates[key]
        self.step_counter[key] += 1
        t = self.step_counter[key]  # Current timestep

        # Update biased moment estimates
        m = self.beta1 * m + (1 - self.beta1) * current_grads
        v = self.beta2 * v + (1 - self.beta2) * (current_grads ** 2)

        # Bias correction
        m_hat = m / (1 - self.beta1 ** t)
        v_hat = v / (1 - self.beta2 ** t)

        # Save updated moments
        self.moment_estimates[key] = [m, v]

        # Return updated weights using Adam formula
        return current_weights - self.lr * m_hat / (np.sqrt(v_hat) + self.epsilon)
