import numpy as np
from Optimization import Optimizers
from Layers import Base
import copy

#Initializes weights and biases randomly
class FullyConnected(Base.BaseLayer):
    def __init__(self, input_size, output_size):

        super().__init__()
        self.trainable = True  # This layer contains learnable parameters
        self.input_size = input_size
        self.output_size = output_size

        # Placeholder initialization (to be overwritten by `initialize`)
        self.weights = np.random.uniform(size=(input_size, output_size))
        self.bias = np.random.uniform(size=(1, output_size))

        self.gradient_weights = None  # Stores gradients for weights
        self.gradient_bias = None     # Stores gradients for biases

        self._optimizer = None        # Will store optimizer objects
        self.input_cache = None       # Store input for backward pass

    #Property getter for optimizer.

    @property
    def optimizer(self):
        return self._optimizer


    #Property setter to assign separate optimizers for weights and bias.
    @optimizer.setter
    def optimizer(self, opt):
        self._optimizer = opt
        self._optimizer.weight = copy.deepcopy(opt)
        self._optimizer.bias = copy.deepcopy(opt)

    #Forward pass of the layer: output = input * weights + bias

    def forward(self, input_tensor):
        self.input_cache = input_tensor
        return np.dot(input_tensor, self.weights) + self.bias

    #Backward pass: computes gradients and updates weights/bias if optimizer is set.
    def backward(self, error_tensor):

        # Gradient w.r.t. input
        input_gradient = np.dot(error_tensor, self.weights.T)

        # Gradients w.r.t. weights and bias
        self.gradient_weights = np.dot(self.input_cache.T, error_tensor)
        self.gradient_bias = np.sum(error_tensor, axis=0, keepdims=True)

        # Update weights and bias using their respective optimizers
        if self._optimizer is not None:
            self.weights = self._optimizer.weight.calculate_update(self.weights, self.gradient_weights)
            self.bias = self._optimizer.bias.calculate_update(self.bias, self.gradient_bias)

        return input_gradient

    #Initializes weights and bias using the given initializer instances.
    def initialize(self, weights_initializer, bias_initializer):
        self.weights = weights_initializer.initialize(
            self.weights.shape, self.input_size, self.output_size
        )
        self.bias = bias_initializer.initialize(
            self.bias.shape, 1, self.output_size
        )
