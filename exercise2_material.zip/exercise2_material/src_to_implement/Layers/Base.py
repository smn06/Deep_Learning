class BaseLayer(object):
    def __init__(self):
        #initialization with trainable false and empty list of weights
        self.trainable = False
        self.weights = []