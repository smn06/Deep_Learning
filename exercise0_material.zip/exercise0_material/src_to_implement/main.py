# calling Checker and Circle class from 'pattern.py'
from pattern import Checker, Circle, Spectrum



# checker = Checker(resolution = 256, tile_size = 32)
# checker.draw()
# checker.show()


# cicle = Circle( resolution= 256, radius = 50, position = (128, 128))

# cicle.draw()
# cicle.show()

spec = Spectrum(100)
spec.draw()
spec.show()

from generator import ImageGenerator

gen = ImageGenerator(
    file_path="images",
    label_path="./data/labels.json",
    batch_size=8,
    image_size=[32, 32, 3],
    rotation=True,
    mirroring=True,
    shuffle=True
)

gen.show()
