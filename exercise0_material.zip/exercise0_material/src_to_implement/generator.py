import os
import json
import numpy as np
import matplotlib.pyplot as plt
from scipy.ndimage import zoom


# In this exercise task you will implement an image generator. Generator objects in python are defined as having a next function.
# This next function returns the next generated object. In our case it returns the input of a neural network each time it gets called.
# This input consists of a batch of images and its corresponding labels.
class ImageGenerator:
    def __init__(self, file_path, label_path, batch_size, image_size, rotation=False, mirroring=False, shuffle=False):
        
        # Define all members of your generator class object as global members here.
        # These need to include:
        # the batch size
        # the image size
        # flags for different augmentations and whether the data should be shuffled for each epoch
        # Also depending on the size of your data-set you can consider loading all images into memory here already.
        # The labels are stored in json format and can be directly loaded as dictionary.
        # Note that the file names correspond to the dicts of the label dictionary.
        
        self.file_path = file_path
        self.batch_size = batch_size
        self.image_size = image_size  # Height, Width, Channel
        self.rotation = rotation
        self.mirroring = mirroring
        self.shuffle = shuffle
        self.current_index = 0
        self.epoch = 0

        with open(label_path, 'r') as f:
            self.labels = json.load(f)

        self.filenames = list(self.labels.keys())
        if self.shuffle:
            np.random.shuffle(self.filenames)

        self.class_dict = {
            0: 'airplane', 1: 'automobile', 2: 'bird', 3: 'cat', 4: 'deer',
            5: 'dog', 6: 'frog', 7: 'horse', 8: 'ship', 9: 'truck'
        }

        self.images = {}
        for fname in self.filenames:
            img_path = os.path.join(self.file_path, f"{fname}.npy")
            img = np.load(img_path)
            self.images[fname] = img

    
    
    def resize_image(self, img):
        
        current_shape = img.shape
        target_shape = self.image_size

        # Compute zoom factors for each dimension
        zoom_factors = [t / c for t, c in zip(target_shape, current_shape)]
        resize = zoom(img, zoom_factors, order=1)
        return resize


    
    
    def next(self):
        # This function creates a batch of images and corresponding labels and returns them.
        # In this context a "batch" of images just means a bunch, say 10 images that are forwarded at once.
        # Note that your amount of total data might not be divisible without remainder with the batch_size.
        # Think about how to handle such cases
        # return images, labels
    
        images = []
        labels = []

        for _ in range(self.batch_size):
            if self.current_index >= len(self.filenames):
                self.current_index = 0
                self.epoch += 1
                if self.shuffle:
                    np.random.shuffle(self.filenames)

            fname = self.filenames[self.current_index]
            label = int(self.labels[fname])  # Ensure label is int
            img = self.images[fname]

            # resize image
            img_resized = self.resize_image(img)

            # image augmentations
            img_augmented = self.augment(img_resized)

            images.append(img_augmented)
            labels.append(label)
            
            # increment of current index
            self.current_index += 1

        return np.array(images), np.array(labels)

    
    
    def augment(self, img):
        # this function takes a single image as an input and performs a random transformation
        # (mirroring and/or rotation) on it and outputs the transformed image

        if self.mirroring and np.random.rand() > 0.5:
            img = np.fliplr(img)
        if self.rotation:
            angle = np.random.choice([0, 90, 180, 270])
            if angle == 90:
                img = np.rot90(img, k=1)
            elif angle == 180:
                img = np.rot90(img, k=2)
            elif angle == 270:
                img = np.rot90(img, k=3)
        return img

    
    def current_epoch(self):
        # return the current epoch number
        return self.epoch

    
    def class_name(self, x):
        # This function returns the class name for a specific input
        return self.class_dict.get(x, "Unknown")

    
    def show(self):
        # In order to verify that the generator creates batches as required, this functions calls next to get a
        # batch of images and labels and visualizes it.
        images, labels = self.next()
        plt.figure(figsize=(12, 6))
        for i in range(self.batch_size):
            plt.subplot(1, self.batch_size, i + 1)
            img = images[i]
            if img.shape[-1] == 1:
                plt.imshow(img.squeeze(), cmap='gray')
            else:
                plt.imshow(np.clip(img / 255.0, 0, 1))
            plt.title(self.class_name(labels[i]))
            plt.axis('off')
        plt.tight_layout()
        plt.show()


