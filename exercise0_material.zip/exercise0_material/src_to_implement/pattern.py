# import numpy and matplotlib

import numpy as np
import matplotlib.pyplot as plt

#import math inverse of cosine for calculating Pi

import math
pi = math.acos(-1)

# Class for Circle with two methods- (draw and show)
class Circle:

    # constructor definition with three arguments
    def __init__(self, resolution: int, radius: int, position: tuple):

        self.resolution = resolution
        self.radius = radius
        self.position = position #co-ordinates of x and y
        self.output = None #Initializer of instance variable 'output'

    # implementation of draw method
    def draw(self):
        # 2D grid creation
        y_axis, x_axis = np.ogrid[:self.resolution, :self.resolution]
        
        # center position of x and y 
        center_x, center_y = self.position

        # distance measurement from center to each pixel
        distance = (x_axis - center_x) ** 2 + (y_axis - center_y) ** 2

        # binary masking
        mask = distance <= self.radius ** 2

        # storing in float 
        self.output = mask.astype(float)

        return self.output.copy()
    

    # implementaion of show function according to the description.pdf
    def show(self):
        plt.imshow(self.output, cmap = 'gray', interpolation = 'nearest')
        plt.title("Binary Circle")
        plt.axis('off')
        plt.show()


# Implementation of Checker Class with draw() and show() methods
class Checker:

    #constructor should pass resolution and tile_size value as int
    def __init__(self, resolution:int, tile_size:int):

        # If the resolution is not divisible by 2*tile_size, it will through exception
        if (resolution % (2*tile_size) != 0):
            raise ValueError("Resolution must be divisible by 2 * tile_size")
    
        self.resolution = resolution
        self.tile_size = tile_size
        self.output = None  #Initializer of instance variable 'output'
    
    # implementation of draw function
    def draw(self):

        # Total number of tiles in each dimension
        tiles_number = self.resolution // self.tile_size

        # base tile 
        base_pattern = np.add.outer(range(tiles_number), range(tiles_number)) % 2
        
        # expansion of each tile to pixels
        self.output = np.kron(base_pattern, np.ones((self.tile_size, self.tile_size)))

        return self.output.copy()
        

    # implementaion of show function according to the description.pdf
    def show(self):
        plt.imshow(self.output, cmap = 'gray', interpolation =  'nearest')
        plt.title("Checkerboard")
        plt.axis('off')
        plt.show()

#implementation of Spectrum class

class Spectrum:
    # constructor with image resolution parameter (W x H)
    def __init__(self, resolution: int):

        self.resolution = resolution
        self.output = None

    def draw(self) -> np.ndarray:
        """
        Builds the spectrum array using linear gradients and broadcasting.
        :return: numpy array of shape (resolution, resolution, 3)
        """
        # initialize empty image
        res = self.resolution
        img = np.zeros((res, res, 3), dtype=np.float32)

        # red channel: horizontal gradient 0 to 1
        red = np.linspace(0.0, 1.0, res)[np.newaxis, :]
        img[..., 0] = red  # broadcast across rows

        # green channel: vertical gradient 0 to 1
        green = np.linspace(0.0, 1.0, res)[:, np.newaxis]
        img[..., 1] = green  # broadcast across columns

        # blue channel: horizontal gradient 1 to 0
        blue = np.linspace(1.0, 0.0, res)
        img[..., 2] = blue[np.newaxis, :]  # broadcast across rows

        self.output = img
        return img.copy()


    #  Display the spectrum image using matplotlib.
    def show(self):
        plt.imshow(self.output, interpolation='nearest')
        plt.axis('off')
        plt.title("RGB spectrum")
        plt.show()
